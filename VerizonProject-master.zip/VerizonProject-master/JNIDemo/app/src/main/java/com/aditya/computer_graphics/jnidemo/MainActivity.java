package com.aditya.computer_graphics.jnidemo;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.aditya.computer_graphics.jnidemo.texturing.OpenGLActivity;

public class MainActivity extends AppCompatActivity {

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    public native String stringFromJNI();

    private Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mContext = this;

        Button button = (Button) findViewById(R.id.my_button);
        button.setText(stringFromJNI()); //set text from native code

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent intent = new Intent(mContext, OpenGLActivity.class);
                startActivity(intent);
            }
        });
    }

    private String nonStaticMethod(String message){
        Toast.makeText(mContext, "Calling non static method from C++ code... "+ message, Toast.LENGTH_SHORT).show();
        return "From Java with love";
    }
}
