package com.aditya.computer_graphics.jnidemo.util;

public class LoggerConfig {
	public static final boolean ON = true;
}
