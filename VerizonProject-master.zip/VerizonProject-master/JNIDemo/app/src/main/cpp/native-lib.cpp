#include <jni.h>
#include <string>

/*
extern "C"
JNIEXPORT jstring JNICALL Java_com_aditya_computer_1graphics_jnidemo_MainActivity_stringFromJNI(
JNIEnv* env, jobject ) {

std::string hello = "Hello from C++";
return env->NewStringUTF(hello.c_str());
}
*/

extern "C"
JNIEXPORT jstring JNICALL Java_com_aditya_computer_1graphics_jnidemo_MainActivity_stringFromJNI( JNIEnv* env, jobject obj){

//    JavaVM *vm;
//    JNIEnv *env;
//    JavaVMInitArgs vm_args;
//    vm_args.version = JNI_VERSION_1_2;
//    vm_args.nOptions = 0;
//    vm_args.ignoreUnrecognized = 1;
//
//    // Construct a VM
//    jint res = JNI_CreateJavaVM(&vm, (void **)&env, &vm_args);

// Construct a String
jstring jstr = env->NewStringUTF("This string comes from JNI");
// First get the class that contains the method you need to call
jclass clazz = env->FindClass("com/aditya/computer_graphics/jnidemo/MainActivity");
// Get the method that you want to call
jmethodID messageMe = env->GetMethodID(clazz, "nonStaticMethod", "(Ljava/lang/String;)Ljava/lang/String;");
// Call the method on the object
jobject result = env->CallObjectMethod(obj, messageMe, jstr);
// Get a C-style string
const char* str = env->GetStringUTFChars((jstring) result, NULL);
printf("%s\n", str);
// Clean up
env->ReleaseStringUTFChars(jstr, str);

//    // Shutdown the VM.
//    vm->DestroyJavaVM();

return env->NewStringUTF("Hello from JNI!");
}
